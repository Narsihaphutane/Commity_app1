// lib/screens/groups_screen.dart

import 'package:commity_app1/screens/commity_admin.dart';
import 'package:commity_app1/model/group_model.dart';
import 'package:commity_app1/screens/group_model.dart';
import 'package:flutter/material.dart';

class SuggestedGroup {
  final String id;
  final String name;
  final String category;
  final String coverUrl;
  final int memberCount;
  final String description;
  bool isJoined;

  SuggestedGroup({
    required this.id,
    required this.name,
    required this.category,
    required this.coverUrl,
    required this.memberCount,
    required this.description,
    this.isJoined = false,
  });
}

class GroupsScreen extends StatefulWidget {
  const GroupsScreen({super.key});

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  final List<SuggestedGroup> _suggestedGroups = [
    SuggestedGroup(id: 's1', name: 'Gaming Legends', category: 'gaming', coverUrl: 'https://picsum.photos/400/200?random=10', memberCount: 45200, description: 'All things gaming – tips, reviews, and tournaments.'),
    SuggestedGroup(id: 's2', name: 'Pro Gamers India', category: 'gaming', coverUrl: 'https://picsum.photos/400/200?random=11', memberCount: 18900, description: 'Connect with pro gamers across India.'),
    SuggestedGroup(id: 's3', name: 'Tech Enthusiasts', category: 'technology', coverUrl: 'https://picsum.photos/400/200?random=12', memberCount: 62000, description: 'Latest in tech, gadgets and innovation.'),
    SuggestedGroup(id: 's4', name: 'Flutter Devs', category: 'technology', coverUrl: 'https://picsum.photos/400/200?random=13', memberCount: 9800, description: 'Flutter & Dart developers community.'),
    SuggestedGroup(id: 's5', name: 'Sports Nation', category: 'sports', coverUrl: 'https://picsum.photos/400/200?random=14', memberCount: 33500, description: 'Cricket, football and all sports talk.'),
    SuggestedGroup(id: 's6', name: 'Fitness Freaks', category: 'fitness', coverUrl: 'https://picsum.photos/400/200?random=15', memberCount: 21000, description: 'Workout routines, diet tips and motivation.'),
    SuggestedGroup(id: 's7', name: 'Music Lovers Hub', category: 'music', coverUrl: 'https://picsum.photos/400/200?random=16', memberCount: 15400, description: 'Share and discover music from all genres.'),
    SuggestedGroup(id: 's8', name: 'Travel Diaries', category: 'travel', coverUrl: 'https://picsum.photos/400/200?random=17', memberCount: 28700, description: 'Travel stories, tips and hidden gems.'),
    SuggestedGroup(id: 's9', name: 'Food & Recipes', category: 'food', coverUrl: 'https://picsum.photos/400/200?random=18', memberCount: 41000, description: 'Home cooking, restaurants and food reviews.'),
    SuggestedGroup(id: 's10', name: 'Startup & Business', category: 'business', coverUrl: 'https://picsum.photos/400/200?random=19', memberCount: 17200, description: 'Entrepreneurs, startups and business ideas.'),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _searchController.addListener(() {
      setState(() => _searchQuery = _searchController.text.trim().toLowerCase());
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  String _formatCount(int count) {
    if (count >= 1000) return '${(count / 1000).toStringAsFixed(1)}K';
    return count.toString();
  }

  List<SuggestedGroup> get _filteredSuggested {
    if (_searchQuery.isEmpty) return _suggestedGroups;
    return _suggestedGroups.where((g) =>
        g.name.toLowerCase().contains(_searchQuery) ||
        g.category.toLowerCase().contains(_searchQuery) ||
        g.description.toLowerCase().contains(_searchQuery)).toList();
  }

  List<Group> get _filteredUserGroups {
    if (_searchQuery.isEmpty) return userCreatedGroups;
    return userCreatedGroups.where((g) =>
        g.name.toLowerCase().contains(_searchQuery) ||
        g.privacy.toLowerCase().contains(_searchQuery)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5FF),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            // ── Purple Header ──────────────────────────────────────────────
            Container(
              color: const Color(0xff8F7CFF),
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).padding.top + 12,
                left: 16,
                right: 16,
                bottom: 0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.of(context).pop(),
                        child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text('Groups', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  // Search bar
                  Container(
                    height: 42,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: TextField(
                      controller: _searchController,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                      decoration: InputDecoration(
                        hintText: 'Search groups...',
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 14),
                        prefixIcon: Icon(Icons.search, color: Colors.white.withOpacity(0.8), size: 20),
                        suffixIcon: _searchQuery.isNotEmpty
                            ? GestureDetector(
                                onTap: () => _searchController.clear(),
                                child: Icon(Icons.close, color: Colors.white.withOpacity(0.8), size: 18),
                              )
                            : null,
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Tab bar
                  TabBar(
                    controller: _tabController,
                    labelColor: Colors.white,
                    unselectedLabelColor: Colors.white54,
                    indicatorColor: Colors.white,
                    indicatorWeight: 3,
                    labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                    unselectedLabelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
                    tabs: [
                      const Tab(text: 'For You'),
                      Tab(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text('Your Groups'),
                            if (userCreatedGroups.isNotEmpty) ...[
                              const SizedBox(width: 4),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
                                child: Text(
                                  '${userCreatedGroups.length}',
                                  style: const TextStyle(color: Color(0xff8F7CFF), fontSize: 10, fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                      const Tab(text: 'Discover'),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildForYouTab(),
                  _buildYourGroupsTab(),
                  _buildDiscoverTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── For You Tab ────────────────────────────────────────────────────────────
  Widget _buildForYouTab() {
    final groups = _filteredSuggested;
    if (groups.isEmpty) {
      return Center(child: Text('No groups found for "$_searchQuery"', style: const TextStyle(color: Color(0xFF6B7280), fontSize: 15)));
    }
    final Map<String, List<SuggestedGroup>> byCategory = {};
    for (final g in groups) {
      byCategory.putIfAbsent(g.category, () => []).add(g);
    }
    return ListView(
      padding: const EdgeInsets.only(top: 12, bottom: 24),
      children: byCategory.entries.map((entry) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(color: const Color(0xFFE8E5FF), borderRadius: BorderRadius.circular(20)),
                child: Text('#${entry.key}', style: const TextStyle(color: Color(0xff8F7CFF), fontSize: 13, fontWeight: FontWeight.w700)),
              ),
            ),
            ...entry.value.map((g) => _buildSuggestedCard(g)),
          ],
        );
      }).toList(),
    );
  }

  Widget _buildSuggestedCard(SuggestedGroup group) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10, offset: const Offset(0, 3))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            child: Image.network(
              group.coverUrl, height: 120, width: double.infinity, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(height: 120, color: const Color(0xFFE8E5FF), child: const Center(child: Icon(Icons.group, color: Color(0xff8F7CFF), size: 40))),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 46, height: 46,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xff8F7CFF), Color(0xffB5ACFF)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: const Icon(Icons.group, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(group.name, style: const TextStyle(color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 3),
                      Text(group.description, style: const TextStyle(color: Color(0xFF6B7280), fontSize: 12), maxLines: 2, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 6),
                      Row(children: [
                        const Icon(Icons.people_outline, size: 13, color: Color(0xFF6B7280)),
                        const SizedBox(width: 4),
                        Text('${_formatCount(group.memberCount)} members', style: const TextStyle(color: Color(0xFF6B7280), fontSize: 12)),
                      ]),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () {
                    setState(() => group.isJoined = !group.isJoined);
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text(group.isJoined ? 'Joined ${group.name}!' : 'Left ${group.name}'),
                      duration: const Duration(seconds: 1),
                      backgroundColor: group.isJoined ? const Color(0xff8F7CFF) : Colors.red,
                    ));
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                    decoration: BoxDecoration(
                      color: group.isJoined ? Colors.white : const Color(0xff8F7CFF),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: const Color(0xff8F7CFF), width: 1.5),
                    ),
                    child: Text(
                      group.isJoined ? 'Joined ✓' : 'Join',
                      style: TextStyle(color: group.isJoined ? const Color(0xff8F7CFF) : Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Your Groups Tab ────────────────────────────────────────────────────────
  Widget _buildYourGroupsTab() {
    final groups = _filteredUserGroups;

    if (userCreatedGroups.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(color: const Color(0xFFE8E5FF), borderRadius: BorderRadius.circular(24)),
                child: const Icon(Icons.group_add_outlined, color: Color(0xff8F7CFF), size: 40),
              ),
              const SizedBox(height: 16),
              const Text('No groups yet', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text("You haven't created or joined any groups yet.", textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF6B7280), fontSize: 14)),
            ],
          ),
        ),
      );
    }

    if (groups.isEmpty) {
      return Center(child: Text('No groups found for "$_searchQuery"', style: const TextStyle(color: Color(0xFF6B7280), fontSize: 15)));
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 12),
      itemCount: groups.length,
      itemBuilder: (context, index) {
        final group = groups[index];
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10, offset: const Offset(0, 3))],
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            leading: CircleAvatar(radius: 28, backgroundImage: NetworkImage(group.imageUrl)),
            title: Text(group.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.black)),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Row(children: [
                Icon(group.privacy == 'Private' ? Icons.lock_outline : Icons.public, size: 13, color: const Color(0xFF6B7280)),
                const SizedBox(width: 4),
                Text(group.privacy, style: const TextStyle(color: Color(0xFF6B7280), fontSize: 12)),
              ]),
            ),
            trailing: ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => CommunityPrivateAdminView(groupName: group.name, privacy: group.privacy),
              )),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE8E5FF),
                foregroundColor: const Color(0xff8F7CFF),
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              ),
              child: const Text('Manage', style: TextStyle(fontWeight: FontWeight.w600)),
            ),
          ),
        );
      },
    );
  }

  // ── Discover Tab ───────────────────────────────────────────────────────────
  Widget _buildDiscoverTab() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, crossAxisSpacing: 16, mainAxisSpacing: 16, childAspectRatio: 0.85,
      ),
      itemCount: 10,
      itemBuilder: (context, index) {
        return Card(
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(child: Image.network('https://picsum.photos/300/300?random=${index + 20}', fit: BoxFit.cover)),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('Community Topic ${index + 1}', style: const TextStyle(fontWeight: FontWeight.w600), textAlign: TextAlign.center),
              ),
            ],
          ),
        );
      },
    );
  }
}