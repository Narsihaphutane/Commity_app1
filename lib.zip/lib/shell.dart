import 'package:commity_app1/screens/create_post.dart';
import 'package:commity_app1/screens/shorts_screen.dart';
import 'package:flutter/material.dart';
import 'screens/feed_screen.dart';
import 'screens/notification_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/profile_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final bool isFeed = index == 0;

    Widget currentScreen;
    switch (index) {
      case 0:
        currentScreen = const FeedScreen();
        break;
      case 1:
        currentScreen = ChatListScreen();
        break;
      case 2:
        // ✅ index 2 la blank/feed dikhav — create button navigate karto
        currentScreen = const FeedScreen();
        break;
      case 3:
        currentScreen = ShortsScreen();
        break;
      case 4:
        currentScreen = ProfileScreen();
        break;
      default:
        currentScreen = const FeedScreen();
    }

    return Scaffold(
      backgroundColor: Colors.white,

      appBar: isFeed
          ? null
          : AppBar(
              backgroundColor: const Color(0xff8F7CFF),
              elevation: 0,
              centerTitle: true,
              title: const Text(
                "Lavender",
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.black),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.notification_add,
                      color: Colors.black),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => NotificationsScreen()),
                  ),
                ),
                const SizedBox(width: 10),
              ],
            ),

      body: currentScreen,

      bottomNavigationBar: Container(
        color: Colors.black,
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 75,
            child: BottomNavigationBar(
              currentIndex: index == 2 ? 0 : index, // ✅ index 2 select dikhvaycha nahi
              onTap: (i) {
                if (i == 2) {
                  // ✅ Navigate to create screen, index change nahi
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => StoryGalleryPickerScreen()),
                  );
                  return;
                }
                setState(() {
                  index = i;
                });
              },
              backgroundColor: Colors.black,
              type: BottomNavigationBarType.fixed,
              showSelectedLabels: false,
              showUnselectedLabels: false,
              selectedItemColor: const Color(0xff8F7CFF),
              unselectedItemColor: Colors.white,
              items: const [
                BottomNavigationBarItem(
                    icon: Icon(Icons.home, size: 26), label: ""),
                BottomNavigationBarItem(
                    icon: Icon(Icons.send_sharp, size: 26), label: ""),
                BottomNavigationBarItem(
                    icon: Icon(Icons.add_circle_outline, size: 30),
                    label: ""),
                BottomNavigationBarItem(
                    icon: Icon(Icons.play_arrow_rounded, size: 26),
                    label: ""),
                BottomNavigationBarItem(
                    icon: Icon(Icons.person, size: 26), label: ""),
              ],
            ),
          ),
        ),
      ),
    );
  }
}